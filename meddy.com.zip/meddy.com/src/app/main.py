from fastapi import FastAPI
import requests
import json
from fastapi.middleware.cors import CORSMiddleware
from fastapi.templating import Jinja2Templates
from functools import lru_cache
import os
# from ..app.config import LRU_MAX_ITEMS

app = FastAPI()
LRU_MAX_ITEMS = int(os.getenv('LRU_MAX_ITEMS', 10))

origins = [
    "http://localhost:8000",
    "localhost:8000"
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"]
)


# api to list and search through news
@lru_cache(maxsize=LRU_MAX_ITEMS)
@app.get("/news")
def list_news(query: str = ''):
    # News_api API
    news_api_apiKey = 'c10fb3b35a84478e8a37edd6e5fb952a'

    # checking whether to list or search in news api
    if query:
        newsapi_response = requests.get(
            f'http://newsapi.org/v2/top-headlines?country=us&q={query}&apiKey={news_api_apiKey}').json()
    else:
        newsapi_response = requests.get(
            f'http://newsapi.org/v2/top-headlines?country=us&apiKey={news_api_apiKey}').json()

    newsapi_news_list = []

    # reformatting news from news api
    for i in newsapi_response['articles']:
        newsapi_news_list.append({'headline': i['title'], 'link': i['url'], 'source': 'newsapi'})

    # Reddit API
    if query:
        reddit_response = requests.get(f'https://www.reddit.com/r/news/search.json?restrict_sr=on&q={query}',
                                       headers={'User-agent': 'Chrome'})
    else:
        reddit_response = requests.get('https://www.reddit.com/r/news/.json', headers={'User-agent': 'Chrome'})


    def reddit_news():
        reddit_news_list = []
        # returns generator object with reddit news api
        def get_news():
            for i in reddit_response.json()['data']['children']:
                n = i['data']['title']
                u = i['data']['url']
                reddit_news_list.append({'headline': n, 'link': u, 'source': 'reddit'})
                yield reddit_news_list

        news = get_news()
        return news

    reddit_news_list = list(reddit_news())
    if len(reddit_news_list) > 0:
        reddit_news_list = list(reddit_news())[0]

    # aggregating news from 2 resources
    news_aggregated = reddit_news_list + newsapi_news_list
    return news_aggregated
