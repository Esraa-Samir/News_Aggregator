from fastapi.testclient import TestClient
import requests
import requests_mock
from ..app import main
import random

client = TestClient(main.app)


# Testing news listing
def test_get_main():
    response = client.get('/news')
    news = response.json()
    news_len = len(news)
    assert response.status_code == 200
    assert (news_len > 0)

    # checking existence of specified fields
    for n in news:
        assert ('headline' in n)
        assert ('link' in n)
        assert ('source' in n)


# Testing search results
def test_search_fields():
    response = client.get('/news?query=trump')
    news = response.json()
    news_len = len(news)
    assert (news_len > 0)

    # checking existence of specified fields
    for n in news:
        assert ('headline' in n)
        assert ('link' in n)
        assert ('source' in n)


# Testing searching with a non existing keyword
def test_empty_search_result():
    response = client.get('/news?query=WeWillWeWillRockYouuuuuuuuuuuuuuu')
    news = response.json()
    news_len = len(news)
    assert response.status_code == 200
    assert news_len == 0


# Mocking NewsApi request
def test_news_api(requests_mock):
    requests_mock.get('http://newsapi.org/v2/top-headlines?country=us&apiKey=c10fb3b35a84478e8a37edd6e5fb952a',
                      text='data')
    assert 'data' == requests.get(
        'http://newsapi.org/v2/top-headlines?country=us&apiKey=c10fb3b35a84478e8a37edd6e5fb952a').text


# Mocking Reddit Api request
def test_reddit_api(requests_mock):
    requests_mock.get('https://www.reddit.com/r/news/.json', text='data')
    assert 'data' == requests.get('https://www.reddit.com/r/news/.json').text
